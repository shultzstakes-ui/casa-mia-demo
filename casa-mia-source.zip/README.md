# Casa Mia by OAna — copie pentru prezentare

Copie independentă din versiunea 14, commit 2553666cd5b3f7fb1a042eb69c84212a6ccc1b1a.

Designul, prețurile, imaginile și animațiile sunt păstrate. Meniul și coșul funcționează local. Comenzile sunt simulări în memoria paginii, fără salvarea numelui, telefonului sau adresei și fără trimiterea lor către un server. După reîncărcare, istoricul simulărilor dispare. Nu există plăți, rezervări confirmate sau panou administrativ real. Pentru formularul demonstrativ folosește date fictive. Solicitarea unei oferte de eveniment poate deschide aplicația de e-mail, ca în proiectul de bază.

## Publicare pe GitHub Pages

1. Creează un repository pentru această prezentare, de exemplu `casa-mia-demo`.
2. Pune conținutul acestui director în rădăcina repository-ului, inclusiv `.github/workflows/pages.yml` (nu încărca arhiva ZIP ca un singur fișier).
3. În Settings → Pages → Source, selectează GitHub Actions.
4. După terminarea fluxului „Casa Mia preview”, adresa publică este afișată în Settings → Pages. Format: `https://NUME-CONT.github.io/NUME-REPOSITORY/`.

Proiectul este static și folosește adrese relative; funcționează atât în subdirector, cât și la rădăcina unui domeniu. Nu necesită DNS pentru adresa github.io. Repository-ul public face codul și imaginile vizibile public.

## Reconstruire

Node.js 24; `npm install`, apoi `npm run build`. După construire, directorul `dist` conține fișierele pentru găzduire statică. Fluxul GitHub Actions construiește și publică acest director automat.

Pentru lansarea comercială se folosește proiectul complet cu backend și domeniul restaurantului; această copie este doar pentru demonstrarea conceptului.
