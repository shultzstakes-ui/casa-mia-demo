export const business={
 name:'Casa Mia by OAna', address:'Strada Safirului 69R, Bragadiru, Ilfov, România',
 email:'contact@casa-mia-byoana.ro', phone:'0756 021 501', eventsPhone:'0761 736 599', eventManager:'Oana Poteca',
 facebook:'https://www.facebook.com/casamiabyoana/', instagram:'https://www.instagram.com/casamiabyoana/',
 directions:'https://www.google.com/maps/search/?api=1&query=Strada%20Safirului%2069R%2C%20Bragadiru%2C%20Ilfov',
 hours:[{days:'Luni–Joi și Duminică',hours:'10:00–22:00'},{days:'Vineri–Sâmbătă',hours:'10:00–23:00'}]
};
export function openingState(date:Date){
 const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/Bucharest',weekday:'short',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(date);
 const p=Object.fromEntries(parts.map(v=>[v.type,v.value]));
 const closing=p.weekday==='Fri'||p.weekday==='Sat'?23:22;
 const now=Number(p.hour)*60+Number(p.minute);
 return {open:now>=600&&now<closing*60,closing:`${closing}:00`};
}
export const originalMenus={
 restaurant:{title:'Meniul restaurantului',images:['restaurant-1.jpg','restaurant-2.jpg']},
 bar:{title:'Meniul de băuturi',images:['bar.jpg']},
 individual:{title:'Cununie / botez · servire individuală',images:['individual-1.png','individual-2.png']},
 platouri:{title:'Cununie / botez · servire pe platouri',images:['platouri-1.png','platouri-2.png']},
 parastas:{title:'Meniurile pentru parastas',images:['parastas-1.png','parastas-2.png']}
};
export type OriginalKind=keyof typeof originalMenus;
export type OfferSection={title:string;items:string[];price?:number;note?:string};
export type EventOffer={id:OriginalKind;title:string;subtitle:string;price?:number;currency?:'EUR'|'RON';service?:number;sections:OfferSection[];extras?:string[]};
export const eventOffers:EventOffer[]=[
 {id:'individual',title:'Cununie & botez',subtitle:'Servire individuală',price:60,currency:'EUR',service:10,sections:[
 {title:'Inclus în meniu',items:['Aranjamente masă','Meniu mâncare','Open bar · maximum 6 ore']},
 {title:'Aperitiv',items:['Frigărui de mozzarella caprese și roșii cherry','Ruladă de pui în crustă de ierburi aromatice','Ruladă cu brânză Philadelphia, somon și spanac','Chifteluțe cu susan','Inele de ceapă pane','Tortilla cu salam Napoli, brânză Philadelphia și ardei copt','Rulou șuncă și crudități','Grisină cu prosciutto','Selecție de salamuri italienești','Măsline, ardei, castravete, roșii cherry']},
 {title:'Fel principal',items:['Tomahawk de porc la grătar','Cartofi dauphinoise','Salată de varză albă cu morcov']},
 {title:'Open bar · maximum 6 ore',items:["Whiskey Ballantine’s, 7 years",'Gin Tonic','Aperol Spritz','Cream whiskey Carolans','Crama Sarica Aniversarium: Sauvignon Blanc, rosé, Cabernet Sauvignon','Apă plată / minerală · 0,75 L','7UP / Pepsi / Mirinda · 1,25 L','Sucuri naturale: măr, portocală, cranberry','Cafea espresso / cappuccino']}
 ],extras:['Shot-uri: +5 €/persoană','File de somon cu orez cu parmezan: +12 €/persoană','File de doradă cu piure și sparanghel: +12 €/persoană']},
 {id:'platouri',title:'Cununie & botez',subtitle:'Servire platouri reci',price:62,currency:'EUR',service:10,sections:[
 {title:'Inclus în meniu',items:['Aranjamente masă','Meniu mâncare','Open bar · maximum 6 ore']},
 {title:'Gustare rece · platouri',items:['Ruladă cu spanac și brânzeturi','Tartă cu icre','Frigărui bocconcini cu mix salamuri italienești','Chifteluțe cu susan','Măsline, roșii cherry, castraveți','Șunculiță de casă','Salată de vinete','Fasole bătută','Cașcaval']},
 {title:'Fel principal · platouri',items:['Ceafă de porc','Pulpă pui','Mititei','Cârnați cu boabe de muștar','Crochete pui','Inele de ceapă','Mozzarella sticks','Cartofi prăjiți','Murături','Sosuri']},
 {title:'Open bar · maximum 6 ore',items:["Whisky Jameson, Ballantine’s, 7 years",'Gin Beefeater','Vodka Absolut','Cream whiskey Carolans','Campari Orange','Aperol Spritz','Vin Crama Sarica Aniversarium: alb, roșu, rosé · 0,7 L','Apă plată / minerală · 0,75 L','Pepsi / Mirinda / 7UP · 1,25 L','Sucuri naturale: măr, portocală','Cafea espresso / cappuccino']}
 ]},
 {id:'parastas',title:'Meniu parastas',subtitle:'Varianta I',currency:'RON',sections:[
 {title:'Gustare rece',price:40,items:['Cașcaval','Pastramă porc','Salam Sibiu','Telemea vacă','Tartină cu icre','Pastă de brânză','Chifteluțe','Crudități: roșii, castraveți, ardei, măsline']},
 {title:'Ciorbă',price:25,items:['Ciorbă de perișoare','Ciorbă de văcuță'],note:'Ciorba este la alegere.'},
 {title:'Fel principal',price:42,items:['Mix grill: ceafă porc 125 g, pulpă pui 125 g, cârnat casă 70 g','Cartofi aromați și salată de varză']}
 ]},
 {id:'parastas',title:'Meniu parastas',subtitle:'Varianta II · de post',currency:'RON',sections:[
 {title:'Gustare rece',price:40,items:['Bruscheta cu roșii','Ciupercuță la cuptor','Dovlecel pane','Vinete','Zacuscă','Bruscheta cu pastă de măsline','Cașcaval vegetal','Crudități: roșii, castraveți, ardei']},
 {title:'Ciorbă',price:25,items:['Ciorbă de legume','Ciorbă de fasole'],note:'Ciorba este la alegere.'},
 {title:'Fel principal',items:['Sarmale de post cu mămăligă: 35 RON','Tocăniță de ciuperci cu mămăligă: 40 RON']},
 {title:'Desert',price:15,items:['Plăcintă mere']}
 ]}
];
