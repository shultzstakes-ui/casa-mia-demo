import {menu} from './menu';

type DemoOrder = {
  id: string;
  createdAt: string;
  status: string;
  mode: string;
  total: number;
  items: {name: string; price: number; quantity: number}[];
  demo: true;
};
const orders: DemoOrder[] = [];
const statuses = ['înregistrată', 'acceptată', 'în preparare', 'gata', 'finalizată'];
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: {'Content-Type': 'application/json'},
});
const currentOrder = (order: DemoOrder) => ({
  ...order,
  status: statuses[Math.min(4, Math.max(0, Math.floor((Date.now() - Date.parse(order.createdAt)) / 4000)))],
});

// A local presentation adapter: no requests, accounts or personal data storage.
export async function demoFetch(path: string, init: RequestInit = {}): Promise<Response> {
  const method = (init.method || 'GET').toUpperCase();
  if (path === '/api/orders' && method === 'GET') {
    return json({orders: orders.map(currentOrder)});
  }
  if (path.startsWith('/api/orders/') && method === 'GET') {
    const order = orders.find(o => o.id === path.slice('/api/orders/'.length));
    return order ? json(currentOrder(order)) : json({error: 'Testul nu există în această sesiune.'}, 404);
  }
  if (path === '/api/reservations' && method === 'POST') {
    return json({id: crypto.randomUUID(), demo: true}, 201);
  }
  if (path !== '/api/orders' || method !== 'POST') {
    return json({error: 'Acțiune indisponibilă în prezentare.'}, 404);
  }
  let payload: {items?: {id: string; quantity: number}[]; mode?: string};
  try { payload = JSON.parse(String(init.body || '{}')); }
  catch { return json({error: 'Coșul nu este valid.'}, 400); }
  if (!payload || !Array.isArray(payload.items) || !payload.items.length) {
    return json({error: 'Adaugă un preparat în coș.'}, 400);
  }
  const quantities = new Map<string, number>();
  for (const item of payload.items) {
    if (!item || !menu.some(d => d.id === item.id) || !Number.isInteger(item.quantity) || item.quantity < 1 || item.quantity > 20) {
      return json({error: 'Un preparat sau o cantitate nu este validă.'}, 400);
    }
    const quantity = (quantities.get(item.id) || 0) + item.quantity;
    if (quantity > 20) return json({error: 'Maximum 20 de porții dintr-un preparat.'}, 400);
    quantities.set(item.id, quantity);
  }
  if ([...quantities.values()].reduce((a, b) => a + b, 0) > 100) {
    return json({error: 'Maximum 100 de porții într-un test.'}, 400);
  }
  const items = [...quantities].map(([id, quantity]) => {
    const dish = menu.find(d => d.id === id)!;
    return {name: dish.name, price: Math.round(dish.price * 100), quantity};
  });
  const order: DemoOrder = {
    id: crypto.randomUUID(), createdAt: new Date().toISOString(), status: statuses[0],
    mode: payload.mode === 'livrare' ? 'livrare' : 'ridicare',
    items, total: items.reduce((sum, item) => sum + item.price * item.quantity, 0), demo: true,
  };
  orders.unshift(order);
  if (orders.length > 50) orders.pop();
  return json(order, 201);
}
