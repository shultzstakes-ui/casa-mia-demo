import React from 'react';
import {createRoot} from 'react-dom/client';
import Home from './page';
import './globals.css';
import './official-content.css';
import './refinements.css';
createRoot(document.getElementById('root')!).render(<Home/>);
