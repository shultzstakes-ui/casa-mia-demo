'use client';

import {ArrowUp} from 'lucide-react';
import {useEffect, useState} from 'react';

export default function BackToTop({raised, hidden}: {raised: boolean; hidden: boolean}) {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const update = () => setVisible(window.scrollY >= 180);
    update();
    window.addEventListener('scroll', update, {passive: true});
    return () => window.removeEventListener('scroll', update);
  }, []);
  if (hidden || !visible) return null;
  return <button
    className={'back-to-top' + (raised ? ' has-cart' : '')}
    aria-label="Înapoi la începutul paginii"
    title="Înapoi sus"
    onClick={() => window.scrollTo({top: 0, behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth'})}
  ><ArrowUp size={19} strokeWidth={1.5}/></button>;
}
