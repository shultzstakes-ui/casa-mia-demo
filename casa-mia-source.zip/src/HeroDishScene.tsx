'use client';

import {useEffect, useRef, useState} from 'react';
import {ArrowUpRight} from 'lucide-react';
import {menu, type Dish} from './menu';
import {plateBounds, plateOutline, platePath} from './hero-geometry';

const intro = menu.find(d => d.name === 'Caracatiță la grătar')!;
const specialties = menu.filter(d => d.category === 'Specialitățile casei');
const slides = [
  {dish: intro, src: './images/hero-motion-v2/intro-plate.webp'},
  ...specialties.map(dish => ({dish, src: `./images/hero-motion-v2/${dish.id}.webp`})),
];
const background = './images/hero-motion-v2/table.webp';

function preload(src: string) {
  return new Promise<void>((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve();
    image.onerror = reject;
    image.src = src;
  });
}

export default function HeroDishScene({onSelect}: {onSelect: (dish: Dish) => void}) {
  const host = useRef<HTMLDivElement>(null);
  const still = useRef<HTMLImageElement>(null);
  const plate = useRef<HTMLButtonElement>(null);
  const platePicture = useRef<HTMLImageElement>(null);
  const caption = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);
  const [dish, setDish] = useState(intro);
  const [frame, setFrame] = useState({width: 0, height: 0, left: 0, top: 0});
  const [label, setLabel] = useState({width: 350, left: 0, top: 0});

  useEffect(() => {
    const box = host.current;
    const image = still.current;
    const text = caption.current;
    if (!box || !image || !text) return;
    const update = () => {
      const w = box.clientWidth, h = box.clientHeight;
      const scale = Math.max(w / 1440, h / 960);
      const position = getComputedStyle(image).objectPosition.split(' ');
      const x = parseFloat(position[0]), y = parseFloat(position[1]);
      const left = (w - 1440 * scale) * (Number.isFinite(x) ? x : 70) / 100;
      const top = (h - 960 * scale) * (Number.isFinite(y) ? y : 50) / 100;
      const width = Math.min(350, Math.max(0, w - 36));
      const labelLeft = Math.max(18, Math.min(w - width - 18, left + 892 * scale - width / 2));
      // Follow the plate's actual cover crop, with the label beneath its lower rim.
      const labelTop = Math.max(0, Math.min(h - text.offsetHeight - (window.innerWidth <= 560 ? 10 : 18), top + 784 * scale + 18));
      setFrame({width: 1440 * scale, height: 960 * scale, left, top});
      setLabel({width, left: labelLeft, top: labelTop});
    };
    update();
    const observer = new ResizeObserver(update);
    observer.observe(box);
    observer.observe(text);
    window.addEventListener('resize', update);
    return () => { observer.disconnect(); window.removeEventListener('resize', update); };
  }, []);

  useEffect(() => {
    const image = plate.current;
    const picture = platePicture.current;
    const text = caption.current;
    if (!image || !picture || !text) return;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
    const supported = typeof image.animate === 'function';
    let disposed = false, loaded = false, visible = true, interacting = false;
    let transitioning = false, current = 0, generation = 0;
    let timer: ReturnType<typeof setTimeout> | undefined;
    let animations: Animation[] = [];
    const clear = () => { if (timer) clearTimeout(timer); timer = undefined; };
    const mayRun = () => !disposed && loaded && supported && visible && !document.hidden && !reduce.matches && !interacting;
    const schedule = (delay = 1400) => {
      clear();
      if (mayRun() && !transitioning) timer = setTimeout(advance, delay);
    };
    const run = (element: HTMLElement, frames: Keyframe[], options: KeyframeAnimationOptions) => {
      const animation = element.animate(frames, {...options, fill: 'forwards'});
      animations.push(animation);
      if (!visible || document.hidden || interacting) animation.pause();
      return animation.finished;
    };
    const resetAnimations = () => { animations.forEach(a => a.cancel()); animations = []; };
    const advance = async () => {
      if (!mayRun() || transitioning) return;
      transitioning = true;
      const token = generation;
      const target = current === slides.length - 1 ? 1 : current + 1;
      const bounds = image.getBoundingClientRect();
      const scene = host.current!.getBoundingClientRect();
      // Distances follow the real plate bounds and the current responsive crop.
      const offX = -(bounds.left - scene.left + bounds.width + 48) / bounds.width * 100;
      const enterY = -(bounds.top - scene.top + bounds.height + 48) / bounds.height * 100;
      const exitY = (scene.height - (bounds.top - scene.top) + 48) / bounds.height * 100;
      text.inert = true;
      image.inert = true;
      try {
        // One physical plate element: the next dish cannot overlap the outgoing one.
        await Promise.all([
          run(image, platePath([0, 0], [offX * .28, exitY * .58], [offX, exitY]),
            {duration: 560, easing: 'cubic-bezier(.42,0,.85,.42)'}),
          run(text, [{opacity: 1, transform: 'translateY(0px)'}, {opacity: 0, transform: 'translateY(6px)'}], {duration: 140, easing: 'ease-in'}),
        ]);
        if (disposed || token !== generation) return;
        // Pin the hidden state before cancelling the completed exit animations.
        image.style.visibility = 'hidden';
        image.style.transform = `translate(${offX}%, ${enterY}%)`;
        text.style.opacity = '0';
        text.style.transform = 'translateY(8px)';
        resetAnimations();
        picture.src = slides[target].src;
        current = target;
        setDish(slides[target].dish);
        // Decode before revealing: the new photograph never flashes in place.
        if (typeof picture.decode === 'function') await picture.decode();
        if (disposed || token !== generation) return;
        image.style.visibility = 'visible';
        await Promise.all([
          run(image, platePath([offX, enterY], [offX * .3, -9], [0, 0]),
            {duration: 640, easing: 'cubic-bezier(.16,.58,.24,1)'}),
          run(text, [{opacity: 0, transform: 'translateY(8px)'}, {opacity: 1, transform: 'translateY(0px)'}], {duration: 220, delay: 390, easing: 'cubic-bezier(.22,1,.36,1)'}),
        ]);
        if (disposed || token !== generation) return;
        image.style.transform = 'translate(0%, 0%)';
        text.style.opacity = '1';
        text.style.transform = 'translateY(0px)';
        resetAnimations();
        text.inert = false;
        image.inert = false;
        transitioning = false;
        schedule();
      } catch {
        if (!disposed && token === generation) {
          // Restore a usable still frame if decoding or animation fails.
          resetAnimations();
          loaded = false;
          current = 0;
          picture.src = slides[0].src;
          image.style.visibility = 'visible';
          image.style.transform = 'translate(0%, 0%)';
          text.style.opacity = '1';
          text.style.transform = 'translateY(0px)';
          text.inert = false;
          image.inert = false;
          transitioning = false;
          setDish(intro);
          setReady(false);
          clear();
        }
      }
    };
    const visibility = () => {
      if (!mayRun()) { clear(); animations.forEach(a => a.pause()); }
      else { animations.forEach(a => a.play()); if (!transitioning) schedule(); }
    };
    const observer = new IntersectionObserver(([entry]) => { visible = entry.isIntersecting; visibility(); }, {threshold: .05});
    if (host.current) observer.observe(host.current);
    const assets = Promise.all([background, ...slides.map(s => s.src)].map(preload)).then(() => {loaded = true;}).catch(() => {loaded = false;});
    const start = () => { void assets.then(() => {if (!disposed && loaded && supported && !reduce.matches) {setReady(true); schedule(1500);}}); };
    const preference = () => {
      generation++;
      clear();
      resetAnimations();
      transitioning = false;
      current = 0;
      picture.src = slides[0].src;
      image.style.visibility = 'visible';
      image.style.transform = 'translate(0%, 0%)';
      text.style.opacity = '1';
      text.style.transform = 'translateY(0px)';
      text.inert = false;
      image.inert = false;
      setDish(intro);
      setReady(false);
      if (!reduce.matches) start();
    };
    const engage = () => {interacting = true; visibility();};
    const leave = () => {interacting = [text, image].some(el => el.matches(':hover') || el.contains(document.activeElement)); visibility();};
    text.addEventListener('pointerenter', engage);
    text.addEventListener('pointerleave', leave);
    text.addEventListener('focusin', engage);
    text.addEventListener('focusout', leave);
    image.addEventListener('pointerenter', engage);
    image.addEventListener('pointerleave', leave);
    image.addEventListener('focusin', engage);
    image.addEventListener('focusout', leave);
    document.addEventListener('visibilitychange', visibility);
    reduce.addEventListener('change', preference);
    if (!reduce.matches && supported) start();
    return () => {
      disposed = true;
      generation++;
      clear();
      resetAnimations();
      observer.disconnect();
      document.removeEventListener('visibilitychange', visibility);
      reduce.removeEventListener('change', preference);
      text.removeEventListener('pointerenter', engage);
      text.removeEventListener('pointerleave', leave);
      text.removeEventListener('focusin', engage);
      text.removeEventListener('focusout', leave);
      image.removeEventListener('pointerenter', engage);
      image.removeEventListener('pointerleave', leave);
      image.removeEventListener('focusin', engage);
      image.removeEventListener('focusout', leave);
    };
  }, []);

  return <>
    <svg width="0" height="0" aria-hidden="true" focusable="false" style={{position: 'absolute'}}><defs>
      <clipPath id="hero-plate-outline" clipPathUnits="objectBoundingBox">
        <path d={plateOutline} transform={`scale(${1 / plateBounds.width} ${1 / plateBounds.height}) translate(${-plateBounds.left} ${-plateBounds.top})`}/>
      </clipPath>
    </defs></svg>
    <div className={'hero-scene' + (ready ? ' is-ready' : '')} ref={host}>
      <img ref={still} className="hero-still" src="./images/hero.webp" alt="Concept culinar Casa Mia: caracatiță la grătar cu orez și unt" fetchPriority="high"/>
      {!ready && frame.width > 0 && <button type="button" className="hero-still-target" onClick={() => onSelect(dish)} aria-label={'Vezi în meniu: ' + dish.name} style={{left: frame.left + plateBounds.left / 1440 * frame.width, top: frame.top + plateBounds.top / 960 * frame.height, width: plateBounds.width / 1440 * frame.width, height: plateBounds.height / 960 * frame.height}}/>}
      <div className="hero-scene-stage" style={frame}>
        <img className="hero-fixed-table" src={background} alt=""/>
        <button type="button" ref={plate} className="hero-moving-plate" onClick={() => onSelect(dish)} aria-label={'Vezi în meniu: ' + dish.name} style={{left: `${plateBounds.left / 1440 * 100}%`, top: `${plateBounds.top / 960 * 100}%`, width: `${plateBounds.width / 1440 * 100}%`, height: `${plateBounds.height / 960 * 100}%`}}>
          <img ref={platePicture} src={slides[0].src} alt="" width={plateBounds.width} height={plateBounds.height} decoding="async"/>
        </button>
      </div>
    </div>
    <div className="hero-dish hero-scene-caption" ref={caption} style={{...label, visibility: frame.width ? 'visible' : 'hidden'}}>
      <span>{dish.id === intro.id ? 'DIN MENIUL NOSTRU' : 'SPECIALITATEA CASEI'}</span>
      <div><h3><button type="button" className="hero-caption-link" onClick={() => onSelect(dish)} aria-label={'Vezi în meniu: ' + dish.name}><span>{dish.name}</span><ArrowUpRight/></button></h3></div>
      <p>{dish.id === intro.id ? 'Orez cu unt · oregano · reducție de vin' : dish.note || dish.ingredients}</p>
    </div>
  </>;
}
